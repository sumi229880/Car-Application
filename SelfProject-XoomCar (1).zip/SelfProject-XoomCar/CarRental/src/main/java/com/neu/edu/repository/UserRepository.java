//package com.neu.edu.repository;
//
//import com.neu.edu.pojo.UserAccount;
//
//public interface UserRepository extends CrudRepository<UserAccount, Long>{
//	
//	 long countByusername(String username);
//	 
//}
