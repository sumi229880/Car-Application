package com.neu.edu.constant;

public enum Roles {

	CUSTOMER,
	ADMIN;
}
