	$(document).ready(function () {
    $('#datepicker').datepicker({
      uiLibrary: 'bootstrap'
    });
});

$(document).ready(function () {
    $('#datepicker2').datepicker({
      uiLibrary: 'bootstrap'
    });
});
	